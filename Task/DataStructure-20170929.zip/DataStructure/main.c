#include <stdio.h>
//#include "fcyc2.h"

int x=12345;
int y=67890;

int main(int argc, char *argv[])
{	
	//DataListDemo();
	DataTreeDemo();	
	
/*
	printf("Value:%d,%d\n",x,y);		
	DuplicateErr();
	
	printf("Addr:%p,%p\n",&x,&y);
	printf("Value:%d,%d\n",x,y);	
*/
	
	//EVC_GrpListDemo();
	
	
	//DataPoolDemo( );
	
	return 0;
}
