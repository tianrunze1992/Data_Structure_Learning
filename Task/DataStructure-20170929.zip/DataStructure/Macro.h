#ifndef _MACRO_H_
#define _MACRO_H_


#define CN_DATA_LOCATE_MODE   			( 1 )   		// 0-��̬����ģʽ 1-��̬����ģʽ


typedef unsigned int 	BOOL; 
typedef unsigned int 	UINT32;
typedef unsigned char 	UINT8;
typedef int             (*FUNCPTR)      ( );            /* ptr to function returning int */


#endif
